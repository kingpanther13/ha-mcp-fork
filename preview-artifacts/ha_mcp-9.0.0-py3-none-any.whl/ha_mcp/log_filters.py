"""MCP SDK log-noise filters shared across every HTTP launcher.

Extracted from :mod:`ha_mcp.__main__` for the same reason as
:mod:`ha_mcp.browser_landing`: the in-process server (the ``ha_mcp_tools``
custom-component worker thread) must never import ``ha_mcp.__main__``, since
that module runs process-global side effects at import time
(``truststore.inject_into_ssl()``, signal handlers, ``asyncio.run``). These
filters only call ``logging.Logger.addFilter`` on specific named loggers --
no ``basicConfig``, no handler or root-logger changes -- so
``install_sdk_log_filters()`` is safe to call from any launcher, including
one that must leave Home Assistant's own logging configuration untouched
(see the ``log_config=None`` comment in ``embedded_server.py``).
"""

from __future__ import annotations

import logging

import anyio


class StatelessSessionLogFilter(logging.Filter):
    """Suppress the routine 'Terminating session: None' log from the MCP SDK.

    In stateless HTTP mode every request creates and tears down a temporary
    session whose id is ``None``, so the SDK emits an INFO
    ``Terminating session: None`` (mcp/server/streamable_http.py) on *every*
    request. The line is routine but looks alarming and has repeatedly
    confused users into thinking the connection is broken.

    Returning ``False`` drops the record at this logger before it reaches any
    handler. (Merely downgrading the level to DEBUG did not work: the level
    gate is applied before the filter runs, so the record was already admitted
    and still emitted -- just relabelled.) Real session terminations carry an
    actual id and are not matched, so they still log.

    # TODO: remove when modelcontextprotocol/python-sdk#2329 is resolved
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """Drop the routine stateless-teardown record; pass everything else."""
        if record.name != "mcp.server.streamable_http":
            return True
        try:
            message = record.getMessage()
        except (ValueError, TypeError):
            # A malformed %-format record on this logger is not our target, and
            # a filter must not raise: filters run in Logger.handle() with no
            # exception handling, so a raise would crash the logging call.
            return True
        # Drop the stateless teardown noise; keep everything else.
        return "Terminating session: None" not in message


_DISCONNECT_TEARDOWN_ERRORS = (anyio.ClosedResourceError, anyio.BrokenResourceError)


def _is_only_disconnect_teardown_errors(err: BaseException) -> bool:
    """True if ``err`` is (or an ExceptionGroup wrapping only) a benign
    streamable-HTTP memory-stream teardown error.

    ``mcp.server.lowlevel.server.Server.run()`` dispatches each incoming
    message via ``anyio.create_task_group().start_soon(...)``, so an error
    raised while delivering one message's response is raised from a
    task-group child -- anyio always wraps that in an ``ExceptionGroup``,
    even for a single failure. The exception a "session crashed" log record
    carries is therefore ``ExceptionGroup(...[<teardown error>])``, not a
    bare one.

    Both ``ClosedResourceError`` and ``BrokenResourceError`` -- sibling
    ``Exception`` subclasses, neither a subclass of the other -- can surface
    here for the same disconnect race: which one depends on which end
    closed first (our end closing raises ``Closed``; the peer's
    ``streamable_http`` ``terminate()`` closing first can wake a parked
    sender into raising ``Broken`` instead, even though the situation is
    identical from the caller's perspective). This repo already treats the
    two as an equivalent pair for streamable-HTTP memory-stream teardown
    elsewhere -- see ``tests/src/haos_runtime.py``'s transient-error tuple.

    Recurse through (possibly nested) groups; any other leaf type means
    this is not the known-benign disconnect race, so the caller should
    leave the record alone.
    """
    if isinstance(err, _DISCONNECT_TEARDOWN_ERRORS):
        return True
    if isinstance(err, BaseExceptionGroup):
        return bool(err.exceptions) and all(
            _is_only_disconnect_teardown_errors(sub) for sub in err.exceptions
        )
    return False


class SessionDisconnectLogFilter(logging.Filter):
    """Demote 'session crashed' tracebacks caused by an already-gone client.

    Every HTTP entry point runs Streamable HTTP in stateless mode (see
    ``ha_mcp.__main__._http_run_kwargs``). A tool call slow enough to outlast
    the client's patience -- a busy Home Assistant instance, a
    resource-contended local LLM host on the client side, or an ordinary HTTP
    timeout -- lets the SDK finish serving the response and tear the
    transport down while ``app.run()`` is still working; the eventual attempt
    to deliver the response then writes into an already-closed memory stream
    and raises ``anyio.ClosedResourceError`` or ``anyio.BrokenResourceError``
    (wrapped in an ``ExceptionGroup`` -- see
    ``_is_only_disconnect_teardown_errors``). The SDK already catches this
    (``except Exception: logger.exception(...)`` in both the stateless and
    stateful session runners of mcp/server/streamable_http_manager.py) -- it
    just logs it as an alarming ERROR-level traceback. That's an expected
    race in a stateless HTTP protocol (the client already gave up), not a
    server bug, so demote it. Any other exception on this logger -- an
    actual crash -- is left untouched.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        """Demote a disconnect-caused 'session crashed' record to WARNING."""
        if record.name != "mcp.server.streamable_http_manager" or not record.exc_info:
            return True

        err = record.exc_info[1]
        if err is None or not _is_only_disconnect_teardown_errors(err):
            return True

        record.msg = (
            f"{record.getMessage()}: client disconnected before response delivery"
        )
        record.args = ()
        record.levelno = logging.WARNING
        record.levelname = "WARNING"
        record.exc_info = None
        record.exc_text = None
        return True


def _add_filter_once(logger_name: str, filter_cls: type[logging.Filter]) -> None:
    """Attach one ``filter_cls`` instance to ``logger_name``, replacing any stale one.

    ``install_sdk_log_filters()`` can run more than once per process: the
    in-process embedded server calls it on every ``_serve()`` reload without
    a process restart, and process-wide ``logging`` state (including each
    named logger's filter list) persists across those reloads. Each reload
    also re-imports this module from scratch (the embedded server purges
    ``ha_mcp.*`` from ``sys.modules`` before reinstalling -- see
    ``_purge_ha_mcp_modules``), so ``filter_cls`` is a BRAND NEW class object
    each time, even though its name is unchanged. A same-``isinstance``-check
    against a filter instance from a PREVIOUS generation would therefore
    never match, letting filters accumulate one more stale instance per
    reload forever. Match by ``(module, qualname)`` instead -- stable across
    reloads of the same module path -- and drop every stale-generation match
    before attaching the current one, so a logger never carries more than
    one filter of a given conceptual type, and it's always this generation's.
    """
    logger = logging.getLogger(logger_name)
    identity = (filter_cls.__module__, filter_cls.__qualname__)
    logger.filters[:] = [
        f
        for f in logger.filters
        if (type(f).__module__, type(f).__qualname__) != identity
    ]
    logger.addFilter(filter_cls())


def install_sdk_log_filters() -> None:
    """Attach the suppression/demotion filters above to their MCP SDK loggers.

    Every HTTP launcher must call this: the CLI (``ha_mcp.__main__``), the
    Home Assistant app's ``start.py``, and the in-process embedded server
    (``ha_mcp_tools/embedded_server.py``) each build and run their own
    Streamable HTTP app, so none of them share another launcher's logging
    setup. Safe to call repeatedly -- see ``_add_filter_once``.
    """
    _add_filter_once("mcp.server.streamable_http", StatelessSessionLogFilter)
    _add_filter_once("mcp.server.streamable_http_manager", SessionDisconnectLogFilter)
