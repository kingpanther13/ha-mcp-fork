"""A middleware for response caching."""

import base64
import hashlib
import json
from collections.abc import Mapping, Sequence
from logging import Logger
from typing import Any, TypedDict

from ha_mcp._vendor import mcp_types
import pydantic_core
from key_value.aio.adapters.pydantic import PydanticAdapter
from key_value.aio.protocols.key_value import AsyncKeyValue
from key_value.aio.stores.memory import MemoryStore
from key_value.aio.wrappers.limit_size import LimitSizeWrapper
from key_value.aio.wrappers.statistics import StatisticsWrapper
from key_value.aio.wrappers.statistics.wrapper import (
    KVStoreCollectionStatistics,
)
from pydantic import Field
from typing_extensions import NotRequired, Self, TypeVar, override

from ha_mcp._vendor.fastmcp.prompts.base import (
    InputRequiredPromptResult,
    Message,
    Prompt,
    PromptResult,
)
from ha_mcp._vendor.fastmcp.resources.base import (
    InputRequiredResourceResult,
    Resource,
    ResourceContent,
    ResourceResult,
)
from ha_mcp._vendor.fastmcp.server.dependencies import get_access_token
from ha_mcp._vendor.fastmcp.server.middleware.middleware import CallNext, Middleware, MiddlewareContext
from ha_mcp._vendor.fastmcp.tools.base import InputRequiredToolResult, Tool, ToolResult
from ha_mcp._vendor.fastmcp.utilities.logging import get_logger
from ha_mcp._vendor.fastmcp.utilities.types import FastMCPBaseModel

logger: Logger = get_logger(name=__name__.removeprefix("ha_mcp._vendor."))


def _is_continuation_leg(context: MiddlewareContext[Any]) -> bool:
    """Whether this request is answering a previous round's ask (SEP-2322).

    A continuation must bypass the cache entirely. Cache keys are built from the
    component's identity and arguments alone, so a continuation shares its key
    with a fresh call: reading could serve a prior flow's final answer to this
    leg, and writing would serve THIS flow's final answer to a later fresh call,
    which would then never be asked the questions at all.

    Either signal marks a continuation. A state-only round (one that carried
    `request_state` without asking anything) retries with `input_responses`
    still `None`.
    """
    fastmcp_ctx = context.fastmcp_context
    if fastmcp_ctx is None:
        return False
    return (
        fastmcp_ctx.input_responses is not None or fastmcp_ctx.request_state is not None
    )


# Constants
ONE_HOUR_IN_SECONDS = 3600
FIVE_MINUTES_IN_SECONDS = 300

ONE_MB_IN_BYTES = 1024 * 1024

ANONYMOUS_AUTH_KEY = "__anonymous__"
DEFAULT_VERSION_CACHE_KEY = "__default__"

BaseModelT = TypeVar("BaseModelT", bound=FastMCPBaseModel)


def _to_base_model(value: FastMCPBaseModel, model_type: type[BaseModelT]) -> BaseModelT:
    """Validate a component's public base fields without serializing its subclass."""
    field_values = {
        name: getattr(value, name)
        for name, field in model_type.model_fields.items()
        if not field.exclude
    }
    return model_type.model_validate(field_values)


class CacheableResourceContent(FastMCPBaseModel):
    """A wrapper for ResourceContent that can be cached."""

    content: str | bytes
    mime_type: str | None = None
    meta: dict[str, Any] | None = None
    is_binary: bool = False


class CacheableResourceResult(FastMCPBaseModel):
    """A wrapper for ResourceResult that can be cached."""

    contents: list[CacheableResourceContent]
    meta: dict[str, Any] | None = None

    def get_size(self) -> int:
        return len(self.model_dump_json())

    @classmethod
    def wrap(cls, value: ResourceResult) -> Self:
        return cls(
            contents=[
                CacheableResourceContent(
                    # JSON cannot distinguish bytes from text. Encode binary
                    # content and retain its type independently of the MIME type.
                    content=base64.b64encode(item.content).decode("ascii")
                    if isinstance(item.content, bytes)
                    else item.content,
                    mime_type=item.mime_type,
                    meta=item.meta,
                    is_binary=isinstance(item.content, bytes),
                )
                for item in value.contents
            ],
            meta=value.meta,
        )

    def unwrap(self) -> ResourceResult:
        return ResourceResult(
            contents=[
                ResourceContent(
                    content=base64.b64decode(item.content)
                    if item.is_binary
                    else item.content,
                    mime_type=item.mime_type,
                    meta=item.meta,
                )
                for item in self.contents
            ],
            meta=self.meta,
        )


class CacheableToolResult(FastMCPBaseModel):
    content: list[mcp_types.ContentBlock]
    structured_content: dict[str, Any] | None
    meta: dict[str, Any] | None
    is_error: bool = False

    @classmethod
    def wrap(cls, value: ToolResult) -> Self:
        return cls(
            content=value.content,
            structured_content=value.structured_content,
            meta=value.meta,
            is_error=value.is_error,
        )

    def unwrap(self) -> ToolResult:
        return ToolResult(
            content=self.content,
            structured_content=self.structured_content,
            meta=self.meta,
            is_error=self.is_error,
        )


class CacheableMessage(FastMCPBaseModel):
    """A wrapper for Message that can be cached."""

    role: str
    content: (
        mcp_types.TextContent
        | mcp_types.ImageContent
        | mcp_types.AudioContent
        | mcp_types.EmbeddedResource
    )


class CacheablePromptResult(FastMCPBaseModel):
    """A wrapper for PromptResult that can be cached."""

    messages: list[CacheableMessage]
    description: str | None = None
    meta: dict[str, Any] | None = None

    def get_size(self) -> int:
        return len(self.model_dump_json())

    @classmethod
    def wrap(cls, value: PromptResult) -> Self:
        return cls(
            messages=[
                CacheableMessage(role=m.role, content=m.content) for m in value.messages
            ],
            description=value.description,
            meta=value.meta,
        )

    def unwrap(self) -> PromptResult:
        return PromptResult(
            messages=[
                Message(content=m.content, role=m.role)  # type: ignore[arg-type]  # ty:ignore[invalid-argument-type]
                for m in self.messages
            ],
            description=self.description,
            meta=self.meta,
        )


class SharedMethodSettings(TypedDict):
    """Shared config for a cache method."""

    ttl: NotRequired[int]
    enabled: NotRequired[bool]


class ListToolsSettings(SharedMethodSettings):
    """Configuration options for Tool-related caching."""


class ListResourcesSettings(SharedMethodSettings):
    """Configuration options for Resource-related caching."""


class ListPromptsSettings(SharedMethodSettings):
    """Configuration options for Prompt-related caching."""


class CallToolSettings(SharedMethodSettings):
    """Configuration options for Tool-related caching."""

    included_tools: NotRequired[list[str]]
    excluded_tools: NotRequired[list[str]]


class ReadResourceSettings(SharedMethodSettings):
    """Configuration options for Resource-related caching."""


class GetPromptSettings(SharedMethodSettings):
    """Configuration options for Prompt-related caching."""


class ResponseCachingStatistics(FastMCPBaseModel):
    list_tools: KVStoreCollectionStatistics | None = Field(default=None)
    list_resources: KVStoreCollectionStatistics | None = Field(default=None)
    list_prompts: KVStoreCollectionStatistics | None = Field(default=None)
    read_resource: KVStoreCollectionStatistics | None = Field(default=None)
    get_prompt: KVStoreCollectionStatistics | None = Field(default=None)
    call_tool: KVStoreCollectionStatistics | None = Field(default=None)


class ResponseCachingMiddleware(Middleware):
    """The response caching middleware offers a simple way to cache responses to mcp methods. The Middleware
    supports cache invalidation via notifications from the server. The Middleware implements TTL-based caching
    but cache implementations may offer additional features like LRU eviction, size limits, and more.

    When items are retrieved from the cache they will no longer be the original objects, but rather no-op objects
    this means that response caching may not be compatible with other middleware that expects original subclasses.

    Notes:
    - Caches `tools/call`, `resources/read`, `prompts/get`, `tools/list`, `resources/list`, and `prompts/list` requests.
    - Cache keys are derived from the method name, requested component version,
      arguments, and the caller's access token. Entries are partitioned per-token
      so that responses filtered by per-component authorization (e.g.
      `auth=require_scopes(...)`) cannot leak across users with different
      permissions. Unauthenticated callers (including STDIO) share a single
      anonymous partition.
    """

    def __init__(
        self,
        cache_storage: AsyncKeyValue | None = None,
        list_tools_settings: ListToolsSettings | None = None,
        list_resources_settings: ListResourcesSettings | None = None,
        list_prompts_settings: ListPromptsSettings | None = None,
        read_resource_settings: ReadResourceSettings | None = None,
        get_prompt_settings: GetPromptSettings | None = None,
        call_tool_settings: CallToolSettings | None = None,
        max_item_size: int = ONE_MB_IN_BYTES,
    ):
        """Initialize the response caching middleware.

        Args:
            cache_storage: The cache backend to use. If None, an in-memory cache is used.
            list_tools_settings: The settings for the list tools method. If None, the default settings are used (5 minute TTL).
            list_resources_settings: The settings for the list resources method. If None, the default settings are used (5 minute TTL).
            list_prompts_settings: The settings for the list prompts method. If None, the default settings are used (5 minute TTL).
            read_resource_settings: The settings for the read resource method. If None, the default settings are used (1 hour TTL).
            get_prompt_settings: The settings for the get prompt method. If None, the default settings are used (1 hour TTL).
            call_tool_settings: The settings for the call tool method. If None, the default settings are used (1 hour TTL).
            max_item_size: The maximum size of items eligible for caching. Defaults to 1MB.
        """

        self._backend: AsyncKeyValue = cache_storage or MemoryStore()

        # When the size limit is exceeded, the put will silently fail
        self._size_limiter: LimitSizeWrapper = LimitSizeWrapper(
            key_value=self._backend, max_size=max_item_size, raise_on_too_large=False
        )
        self._stats: StatisticsWrapper = StatisticsWrapper(key_value=self._size_limiter)

        self._list_tools_settings: ListToolsSettings = (
            list_tools_settings or ListToolsSettings()
        )
        self._list_resources_settings: ListResourcesSettings = (
            list_resources_settings or ListResourcesSettings()
        )
        self._list_prompts_settings: ListPromptsSettings = (
            list_prompts_settings or ListPromptsSettings()
        )

        self._read_resource_settings: ReadResourceSettings = (
            read_resource_settings or ReadResourceSettings()
        )
        self._get_prompt_settings: GetPromptSettings = (
            get_prompt_settings or GetPromptSettings()
        )
        self._call_tool_settings: CallToolSettings = (
            call_tool_settings or CallToolSettings()
        )

        self._list_tools_cache: PydanticAdapter[list[Tool]] = PydanticAdapter(
            key_value=self._stats,
            pydantic_model=list[Tool],
            default_collection="tools/list",
        )

        self._list_resources_cache: PydanticAdapter[list[Resource]] = PydanticAdapter(
            key_value=self._stats,
            pydantic_model=list[Resource],
            default_collection="resources/list",
        )

        self._list_prompts_cache: PydanticAdapter[list[Prompt]] = PydanticAdapter(
            key_value=self._stats,
            pydantic_model=list[Prompt],
            default_collection="prompts/list",
        )

        self._read_resource_cache: PydanticAdapter[CacheableResourceResult] = (
            PydanticAdapter(
                key_value=self._stats,
                pydantic_model=CacheableResourceResult,
                default_collection="resources/read",
            )
        )

        self._get_prompt_cache: PydanticAdapter[CacheablePromptResult] = (
            PydanticAdapter(
                key_value=self._stats,
                pydantic_model=CacheablePromptResult,
                default_collection="prompts/get",
            )
        )

        self._call_tool_cache: PydanticAdapter[CacheableToolResult] = PydanticAdapter(
            key_value=self._stats,
            pydantic_model=CacheableToolResult,
            default_collection="tools/call",
        )

    @override
    async def on_list_tools(
        self,
        context: MiddlewareContext[mcp_types.ListToolsRequest],
        call_next: CallNext[mcp_types.ListToolsRequest, Sequence[Tool]],
    ) -> Sequence[Tool]:
        """List tools from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        if self._list_tools_settings.get("enabled") is False:
            return await call_next(context)

        cache_key: str = _get_auth_partition_key()

        # an empty list is a cached result, not a miss: `get` returns None when the key is
        # absent, so testing truthiness would re-list on every request for any caller whose
        # filtered view is empty
        cached_value = await self._list_tools_cache.get(key=cache_key)
        if cached_value is not None:
            return cached_value

        tools: Sequence[Tool] = await call_next(context)

        # Turn any subclass of Tool into a Tool
        cacheable_tools = [_to_base_model(tool, Tool) for tool in tools]

        await self._list_tools_cache.put(
            key=cache_key,
            value=cacheable_tools,
            ttl=self._list_tools_settings.get("ttl", FIVE_MINUTES_IN_SECONDS),
        )

        return cacheable_tools

    @override
    async def on_list_resources(
        self,
        context: MiddlewareContext[mcp_types.ListResourcesRequest],
        call_next: CallNext[mcp_types.ListResourcesRequest, Sequence[Resource]],
    ) -> Sequence[Resource]:
        """List resources from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        if self._list_resources_settings.get("enabled") is False:
            return await call_next(context)

        cache_key: str = _get_auth_partition_key()

        # an empty list is a cached result, not a miss (see on_list_tools)
        cached_value = await self._list_resources_cache.get(key=cache_key)
        if cached_value is not None:
            return cached_value

        resources: Sequence[Resource] = await call_next(context)

        # Turn any subclass of Resource into a Resource
        cacheable_resources = [
            _to_base_model(resource, Resource) for resource in resources
        ]

        await self._list_resources_cache.put(
            key=cache_key,
            value=cacheable_resources,
            ttl=self._list_resources_settings.get("ttl", FIVE_MINUTES_IN_SECONDS),
        )

        return cacheable_resources

    @override
    async def on_list_prompts(
        self,
        context: MiddlewareContext[mcp_types.ListPromptsRequest],
        call_next: CallNext[mcp_types.ListPromptsRequest, Sequence[Prompt]],
    ) -> Sequence[Prompt]:
        """List prompts from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        if self._list_prompts_settings.get("enabled") is False:
            return await call_next(context)

        cache_key: str = _get_auth_partition_key()

        # an empty list is a cached result, not a miss (see on_list_tools)
        cached_value = await self._list_prompts_cache.get(key=cache_key)
        if cached_value is not None:
            return cached_value

        prompts: Sequence[Prompt] = await call_next(context)

        # Turn any subclass of Prompt into a Prompt
        cacheable_prompts = [_to_base_model(prompt, Prompt) for prompt in prompts]

        await self._list_prompts_cache.put(
            key=cache_key,
            value=cacheable_prompts,
            ttl=self._list_prompts_settings.get("ttl", FIVE_MINUTES_IN_SECONDS),
        )

        return cacheable_prompts

    @override
    async def on_call_tool(
        self,
        context: MiddlewareContext[mcp_types.CallToolRequestParams],
        call_next: CallNext[mcp_types.CallToolRequestParams, ToolResult],
    ) -> ToolResult:
        """Call a tool from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        tool_name = context.message.name

        if self._call_tool_settings.get(
            "enabled"
        ) is False or not self._matches_tool_cache_settings(tool_name=tool_name):
            return await call_next(context)

        if _is_continuation_leg(context):
            return await call_next(context)

        cache_key: str = _make_call_tool_cache_key(
            msg=context.message, auth_key=_get_auth_partition_key()
        )

        if cached_value := await self._call_tool_cache.get(key=cache_key):
            return cached_value.unwrap()

        tool_result: ToolResult = await call_next(context)

        # Never cache a multi-round-trip ask (SEP-2322). An
        # InputRequiredToolResult is a request for client input on this leg, not
        # a stable answer; caching it would replay a stale question to later
        # callers and bypass the tool's own per-round logic. Return it straight
        # through without storing.
        if isinstance(tool_result, InputRequiredToolResult):
            return tool_result

        # A task-augmented call returns a CreateTaskResult (the tasks extension)
        # up through this middleware — an acknowledgement that the work was
        # enqueued, not a cacheable answer, and without a ToolResult's
        # content/structured_content. Pass any non-ToolResult straight through
        # rather than crash wrapping it (the crash would fire after the task is
        # already enqueued, so a client retry could duplicate side effects).
        if not isinstance(tool_result, ToolResult):
            return tool_result

        # Never cache an error result. A tool that reports failure by returning
        # is_error=True is describing this attempt, not a stable answer — the
        # upstream 503 or bad gateway it is reporting is exactly the kind of
        # thing that clears on retry. Caching it would pin the failure in place
        # for the full TTL and stop the tool from ever being retried.
        if tool_result.is_error:
            return tool_result

        cacheable_tool_result: CacheableToolResult = CacheableToolResult.wrap(
            value=tool_result
        )

        await self._call_tool_cache.put(
            key=cache_key,
            value=cacheable_tool_result,
            ttl=self._call_tool_settings.get("ttl", ONE_HOUR_IN_SECONDS),
        )

        return cacheable_tool_result.unwrap()

    @override
    async def on_read_resource(
        self,
        context: MiddlewareContext[mcp_types.ReadResourceRequestParams],
        call_next: CallNext[mcp_types.ReadResourceRequestParams, ResourceResult],
    ) -> ResourceResult:
        """Read a resource from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        if self._read_resource_settings.get("enabled") is False:
            return await call_next(context)

        if _is_continuation_leg(context):
            return await call_next(context)

        cache_key: str = _make_read_resource_cache_key(
            msg=context.message, auth_key=_get_auth_partition_key()
        )
        cached_value: CacheableResourceResult | None

        if cached_value := await self._read_resource_cache.get(key=cache_key):
            return cached_value.unwrap()

        value: ResourceResult = await call_next(context)

        # Never cache a multi-round-trip ask (SEP-2322). An
        # InputRequiredResourceResult is a request for client input on this leg,
        # not a stable answer, and it carries no contents — wrapping it would
        # cache an empty read and the client would never see the question.
        if isinstance(value, InputRequiredResourceResult):
            return value

        cached_value = CacheableResourceResult.wrap(value)

        await self._read_resource_cache.put(
            key=cache_key,
            value=cached_value,
            ttl=self._read_resource_settings.get("ttl", ONE_HOUR_IN_SECONDS),
        )

        return cached_value.unwrap()

    @override
    async def on_get_prompt(
        self,
        context: MiddlewareContext[mcp_types.GetPromptRequestParams],
        call_next: CallNext[mcp_types.GetPromptRequestParams, PromptResult],
    ) -> PromptResult:
        """Get a prompt from the cache, if caching is enabled, and the result is in the cache. Otherwise,
        otherwise call the next middleware and store the result in the cache if caching is enabled."""
        if self._get_prompt_settings.get("enabled") is False:
            return await call_next(context)

        if _is_continuation_leg(context):
            return await call_next(context)

        cache_key: str = _make_get_prompt_cache_key(
            msg=context.message, auth_key=_get_auth_partition_key()
        )

        if cached_value := await self._get_prompt_cache.get(key=cache_key):
            return cached_value.unwrap()

        value: PromptResult = await call_next(context)

        # Never cache a multi-round-trip ask (SEP-2322). An
        # InputRequiredPromptResult is a request for client input on this leg,
        # not a stable answer, and it carries no messages — wrapping it would
        # cache an empty prompt and the client would never see the question.
        if isinstance(value, InputRequiredPromptResult):
            return value

        cached_value = CacheablePromptResult.wrap(value)

        await self._get_prompt_cache.put(
            key=cache_key,
            value=cached_value,
            ttl=self._get_prompt_settings.get("ttl", ONE_HOUR_IN_SECONDS),
        )

        return cached_value.unwrap()

    def _matches_tool_cache_settings(self, tool_name: str) -> bool:
        """Check if the tool matches the cache settings for tool calls."""

        if included_tools := self._call_tool_settings.get("included_tools"):
            if tool_name not in included_tools:
                return False

        if excluded_tools := self._call_tool_settings.get("excluded_tools"):
            if tool_name in excluded_tools:
                return False

        return True

    def statistics(self) -> ResponseCachingStatistics:
        """Get the statistics for the cache."""
        return ResponseCachingStatistics(
            list_tools=self._stats.statistics.collections.get("tools/list"),
            list_resources=self._stats.statistics.collections.get("resources/list"),
            list_prompts=self._stats.statistics.collections.get("prompts/list"),
            read_resource=self._stats.statistics.collections.get("resources/read"),
            get_prompt=self._stats.statistics.collections.get("prompts/get"),
            call_tool=self._stats.statistics.collections.get("tools/call"),
        )


def _get_arguments_str(arguments: dict[str, Any] | None) -> str:
    """Get a canonical string representation of the arguments."""

    if arguments is None:
        return "null"

    try:
        return json.dumps(
            pydantic_core.to_jsonable_python(arguments, fallback=str),
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
            default=str,
        )

    except TypeError:
        return repr(arguments)


def _hash_cache_key(value: str) -> str:
    """Build a fixed-length SHA-256 cache key from request-derived input."""

    return hashlib.sha256(value.encode()).hexdigest()


def _get_auth_partition_key() -> str:
    """Return a stable, hashed identifier for the current access token.

    Cache entries are partitioned by access token so that responses filtered
    by per-component authorization (e.g. `auth=require_scopes(...)`) are not
    leaked across users with different permissions. Unauthenticated callers
    (including STDIO) share a single anonymous partition.
    """

    token = get_access_token()
    if token is None:
        return ANONYMOUS_AUTH_KEY
    return _hash_cache_key(token.token)


def _get_component_version_cache_key(msg: mcp_types.RequestParams) -> str:
    """Return a cache partition for the requested component version."""
    if not msg.meta:
        return DEFAULT_VERSION_CACHE_KEY

    fastmcp_meta = msg.meta.get("fastmcp")
    if not isinstance(fastmcp_meta, Mapping):
        return DEFAULT_VERSION_CACHE_KEY

    version = fastmcp_meta.get("version")
    if version is None:
        return DEFAULT_VERSION_CACHE_KEY

    # Encode the selector as a canonical JSON value so strings and range
    # selectors cannot collide and equivalent selectors share a partition.
    return f"__version__:{_get_arguments_str({'version': version})}"


def _make_call_tool_cache_key(
    msg: mcp_types.CallToolRequestParams, auth_key: str = ANONYMOUS_AUTH_KEY
) -> str:
    """Make a cache key for a tool call using name, version, and arguments."""

    return _hash_cache_key(
        f"{auth_key}:{_get_component_version_cache_key(msg)}:{msg.name}:"
        f"{_get_arguments_str(msg.arguments)}"
    )


def _make_read_resource_cache_key(
    msg: mcp_types.ReadResourceRequestParams, auth_key: str = ANONYMOUS_AUTH_KEY
) -> str:
    """Make a cache key for a resource read using version and URI."""

    return _hash_cache_key(
        f"{auth_key}:{_get_component_version_cache_key(msg)}:{msg.uri}"
    )


def _make_get_prompt_cache_key(
    msg: mcp_types.GetPromptRequestParams, auth_key: str = ANONYMOUS_AUTH_KEY
) -> str:
    """Make a cache key for a prompt get using name, version, and arguments."""

    return _hash_cache_key(
        f"{auth_key}:{_get_component_version_cache_key(msg)}:{msg.name}:"
        f"{_get_arguments_str(msg.arguments)}"
    )
