"""FastMCP on_call_tool middleware for tool security policies."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, NoReturn

import anyio
from anyio.to_thread import run_sync as run_in_thread

from ha_mcp._vendor.fastmcp.server.middleware.middleware import (
    CallNext,
    Middleware,
    MiddlewareContext,
)

from ..errors import ErrorCode, create_error_response
from ..renamed_tools import current_tool_name
from ..tool_dispatch import CALL_PROXY_META_TOOLS, is_approval_management_call
from ..tools.helpers import raise_tool_error, safe_progress
from .approval_queue import ApprovalQueue, PendingApproval, compute_args_hash
from .evaluator import (
    Verdict,
    evaluate,
    find_matching_rule,
    has_dynamic_selector_targets,
    normalize_stringified_containers,
)
from .events import emit_approval_requested
from .model import Policy, Rule
from .mrtr import ApprovalContinuation, supports_mrtr

if TYPE_CHECKING:
    from ..client.rest_client import HomeAssistantClient

logger = logging.getLogger(__name__)

PROXY_META_TOOLS = CALL_PROXY_META_TOOLS | {"ha_search_tools"}


def _passes_ungated(name: str, args: dict[str, Any]) -> bool:
    """Calls that must bypass gating: proxy meta-tools + queue management."""
    return name in PROXY_META_TOOLS or is_approval_management_call(name, args)


class PolicyMiddleware(Middleware):
    """Gate tool calls against a Policy, blocking with progress heartbeats."""

    def __init__(
        self,
        *,
        policy_provider: Callable[[], Policy],
        queue: ApprovalQueue,
        wait_seconds: int | None = None,
        get_client: Callable[[], HomeAssistantClient] | None = None,
        ensure_decisions_listener: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        """Gate tool calls against ``policy_provider``'s policy.

        ``get_client`` supplies the Home Assistant REST client used to
        announce a pending approval on the event bus. Without it the gate
        still works, it just stays invisible outside the settings UI.

        ``ensure_decisions_listener`` opens the return channel that lets a
        response event decide the request being announced. It runs before
        the announcement so a listener cannot answer an event that arrived
        while nothing was subscribed, and it is a no-op unless the user
        switched deciding-from-events on.
        """
        self._policy_provider = policy_provider
        self._queue = queue
        self._wait_override = wait_seconds
        self._get_client = get_client
        self._ensure_decisions_listener = ensure_decisions_listener

    async def on_call_tool(
        self, context: MiddlewareContext, call_next: CallNext
    ) -> Any:
        """Gate one tool call against the policy, blocking on approval if required.

        Loads the policy, evaluates the call, and -- when approval is
        required -- finds or creates a pending queue entry and waits up to
        the configured window for a decision. Identical static calls share
        one queue entry so the user sees a single approval row, but the
        approval itself is consumed exactly once
        (``PendingApproval.claim``): a second waiter woken by the same
        decision gets its own pending row instead of riding the first
        call's click. A dynamic selector call
        (``has_dynamic_selector_targets``) never shares or reuses another
        call's pending entry, and is never reissued on TTL eviction: see
        the inline comments above the ``existing =``, ``pending =``, and
        eviction-reissue assignments below for why binding it to this one
        invocation is a correctness requirement, not just extra caution.
        """
        try:
            # Hoist sync file read off the event loop — a slow FS shouldn't
            # pause the fastmcp request handler's task.
            policy = await run_in_thread(self._policy_provider)
        except ValueError as e:
            # Fail-closed: a corrupt or invalid tool_policy.json is a
            # security-relevant config error. Passing through would
            # silently bypass every rule the user configured. Raise a
            # structured ToolError so the LLM (and the user) sees what
            # to do, instead of crashing the call with an opaque trace.
            logger.exception("Tool security policy load failed; failing closed")
            raise_tool_error(
                create_error_response(
                    ErrorCode.POLICY_LOAD_FAILED,
                    f"Tool security policy file is corrupt or invalid: {e}. "
                    "Edit or delete tool_policy.json and reload.",
                    suggestions=[
                        "Open the Tool Security Policies tab in the web UI "
                        "to view/repair the policy.",
                    ],
                )
            )
        # RenamedToolAliasMiddleware runs ahead of this one and normally
        # rewrites a retired name before it arrives. Resolving it again costs a
        # dict lookup and removes the ordering dependency, which here is the
        # difference between gated and ungated: rules are keyed on the current
        # name, and under a require-approval list ``evaluate`` returns ALLOW
        # when nothing matches, so a gate reading a stale name lets the call
        # through (under an allow list it would gate an approved call).
        name = current_tool_name(context.message.name)
        # Normalize stringified JSON containers (a client like Claude Desktop
        # stdio can send a nested parameter, e.g. `selector`, as a JSON
        # string rather than an object) before any evaluation/hashing below
        # — the tool's own Pydantic coercion happens only later, inside
        # call_next, which is too late for a predicate path or the selector
        # fail-safe to see the real structure. This only affects the local
        # copy used for gating; `context` itself is untouched, so the actual
        # tool call still receives the client's original wire shape.
        try:
            args = normalize_stringified_containers(context.message.arguments or {})
        except RecursionError:
            # Fail-closed for the same reason the corrupt-policy branch
            # above is: silently evaluating (and hashing) unnormalized args
            # would let a rule scoped to a nested selector-inspectable field
            # (e.g. args.selector.domain) never match, and the call would
            # ALLOW. Reachable only via genuinely deep real nesting in the
            # caller's own args (a stringified container decoding into deep
            # nesting cannot reach this -- see the docstring), so this is
            # about the gate degrading loudly rather than a realistic
            # traffic pattern.
            logger.warning(
                "policy middleware: args normalization hit RecursionError "
                "for tool=%s; failing closed",
                name,
            )
            raise_tool_error(
                create_error_response(
                    ErrorCode.POLICY_ARGS_TOO_DEEPLY_NESTED,
                    "This call's arguments are nested too deeply to "
                    "evaluate safely against the security policy.",
                    suggestions=[
                        "Reduce the nesting depth of the tool call arguments "
                        + "and retry.",
                    ],
                )
            )

        if _passes_ungated(name, args):
            return await call_next(context)

        args_hash = compute_args_hash(args)
        resumed = ApprovalContinuation.resume(
            context, self._queue, name, args_hash, policy
        )
        if evaluate(name, args, policy) != Verdict.REQUIRE_APPROVAL:
            return await call_next(context)

        return await self._gate_approval(
            context, call_next, policy, name, args, args_hash, resumed
        )

    async def _gate_approval(
        self,
        context: MiddlewareContext,
        call_next: CallNext,
        policy: Policy,
        name: str,
        args: dict[str, Any],
        args_hash: str,
        resumed: tuple[ApprovalContinuation, PendingApproval] | None,
    ) -> Any:
        """Wait on one approval, returning a continuation only while it is pending."""
        rule = find_matching_rule(name, args, policy)
        dynamic_targets = has_dynamic_selector_targets(name, args)
        remember_minutes = (
            0 if dynamic_targets else rule.remember_minutes if rule else 0
        )
        # An allow list has no remember window (find_matching_rule returns no
        # rule for it, so remember_minutes is 0). A remembered entry is then
        # left over from a require-approval list: a call left pending there
        # and approved after the switch, or a switch saved from the sidecar or
        # by a hand edit, neither of which clears this cache. It must not
        # approve a call the allow list gates.
        reads_remembered = (
            not dynamic_targets and policy.rule_effect == "require_approval"
        )

        if (
            resumed is None
            and reads_remembered
            and self._queue.is_remembered(name, args_hash)
        ):
            return await call_next(context)

        # A dynamic selector call must never consume an entry it did not
        # itself create and is not itself still waiting on. Two reachable
        # ways an unguarded lookup here breaks the "approve once, dispatch
        # once, against fresh topology" invariant: (1) a race -- decide()
        # flips a waiter's own PendingApproval.decision before the waiter's
        # task is rescheduled, so a second, concurrent call's find() can
        # observe "approved" and consume-and-dispatch before the original
        # waiter wakes and does the same from its own reference, executing
        # the click twice; (2) a later, non-racy call -- the original call
        # times out and is told to re-call, the user approves afterwards,
        # and ANY later identical call within approval_ttl_minutes claims
        # that stale approval and dispatches against topology re-resolved
        # at that later moment -- exactly the reuse-across-a-time-gap this
        # PR disables `remember_minutes` to prevent, just via a different
        # mechanism. Binding a dynamic entry to its creating invocation
        # closes both: only the call that created a pending entry ever
        # observes it (via its own `pending` reference after its own wait,
        # below), so every other call -- concurrent or a later retry --
        # unconditionally mints its own independent entry and wait window.
        # The accepted cost is that a retry never silently rides an earlier
        # approval: each blocked call gets its own approval row, and only
        # approving the row for the CURRENTLY-blocked call has any effect.
        if resumed is None and self._resolve_already_decided(
            name,
            args_hash,
            dynamic_targets=dynamic_targets,
            reads_remembered=reads_remembered,
            remember_minutes=remember_minutes,
        ):
            return await call_next(context)

        continuation, pending = (
            resumed
            if resumed is not None
            else (
                None,
                await self._new_pending(
                    name,
                    args_hash,
                    args,
                    policy=policy,
                    dynamic_targets=dynamic_targets,
                ),
            )
        )
        await self._announce(pending, rule, dynamic_targets=dynamic_targets)

        wait = (
            self._wait_override
            if self._wait_override is not None
            else policy.wait_seconds
        )
        if continuation is None and supports_mrtr(context) and wait > 0:
            continuation = ApprovalContinuation.start(
                pending, policy, wait, dynamic_targets=dynamic_targets
            )
        await self._wait_for_decision(
            context, pending, continuation.wait_seconds() if continuation else wait
        )

        if pending.decision == "approved":
            if self._claim_approval(
                pending,
                name,
                args_hash,
                reads_remembered=reads_remembered and resumed is None,
                remember_minutes=remember_minutes,
            ):
                return await call_next(context)
            # Another waiter on this shared entry consumed the approval
            # first. This call has none of its own, so it must not ride
            # that click: mint a fresh row and tell the caller to get it
            # approved. Its wait budget is already spent, so it does not
            # wait again here -- re-waiting would also let a steady
            # stream of identical calls starve one another.
            pending = await self._new_pending(
                name, args_hash, args, policy=policy, dynamic_targets=dynamic_targets
            )
            await self._announce(pending, rule, dynamic_targets=dynamic_targets)
            self._raise_pending_error(pending, rule, dynamic_targets=dynamic_targets)
        if pending.decision == "denied":
            self._queue.remove(pending.token)
            self._raise_denied_error()

        if continuation is not None:
            result = continuation.next_result(self._queue)
            if result is not None:
                return result

        pending = self._finalize_timed_out_pending(
            pending, dynamic_targets=dynamic_targets, policy=policy, name=name
        )
        await self._announce_reissued(pending, rule, dynamic_targets=dynamic_targets)
        self._raise_pending_error(pending, rule, dynamic_targets=dynamic_targets)
        return None  # py/mixed-returns: explicit terminal; error handlers above always raise (NoReturn), unreachable

    async def _announce_reissued(
        self,
        pending: PendingApproval,
        rule: Rule | None,
        *,
        dynamic_targets: bool,
    ) -> None:
        """Announce an entry ``_finalize_timed_out_pending`` just reissued.

        What usually reaches an event here is a reissue: the entry this
        call waited on was announced before the wait and ``mark_notified``
        refuses a second event for it. A reissue carries a new token, and
        the token in the first event is dead by then, so a listener holding
        it needs the new one. Not only a reissue, though -- when the first
        announcement found no client it left the one-shot unspent, and the
        same entry can still take its first event here.

        Never on the dynamic path. There ``_finalize_timed_out_pending``
        REMOVES the entry rather than reissuing it, so an announcement
        would advertise a token the queue no longer knows — reachable when
        the first announcement found no client and left the one-shot
        unspent. That also forgoes the channel-recovery attempt in
        ``_announce``, which costs nothing here: the entry this call would
        have announced is gone, and the next request runs the attempt.
        """
        if dynamic_targets:
            return
        await self._announce(pending, rule, dynamic_targets=dynamic_targets)

    async def _announce(
        self,
        pending: PendingApproval,
        rule: Rule | None,
        *,
        dynamic_targets: bool = False,
    ) -> None:
        """Open the response channel, and fire the approval-requested event
        for an entry that has not been announced yet.

        Each pending entry is announced exactly once
        (``PendingApproval.mark_notified``), so concurrent identical calls
        that share one queue row also share one notification.

        The client is resolved BEFORE the one-shot is consumed: taking it
        first would burn the entry's single announcement on a client that
        never materialised, and a later reissue of that same entry could
        then never announce either.

        Opening the response channel is NOT tied to that one-shot. The
        announcement is per entry; the channel is per connection, and the
        two fail independently -- a subscription that never opened, or one
        a reconnect dropped afterwards, leaves an entry that is already
        marked notified with no way back. Identical retries reuse that
        entry, so gating recovery on the latch would mean the channel can
        only ever be restored by a request nobody has asked for yet. The
        attempt therefore runs on every pass that gets as far as a client,
        and only the event itself is suppressed for an entry already
        announced. Where there is no client at all, neither happens: the
        early returns below cover both.
        """
        if self._get_client is None:
            return
        try:
            client = self._get_client()
        except Exception:
            logger.warning(
                "policy middleware: no Home Assistant client to announce the "
                "pending approval for tool=%s; the request is still queued "
                "and visible in the settings UI",
                pending.tool_name,
                exc_info=True,
            )
            return
        # Ahead of the event, so a responder that answers the instant the
        # notification arrives finds the channel already open -- and ahead of
        # the one-shot, because this await is not short: a cancellation
        # between taking the latch and firing the event would leave the entry
        # marked announced with nothing ever announced, and every identical
        # retry reuses that entry.
        await self._ensure_decision_channel()
        if not pending.mark_notified():
            return
        await emit_approval_requested(client, pending, rule, single_use=dynamic_targets)

    async def _ensure_decision_channel(self) -> None:
        """Open the response channel, if the user turned it on.

        Best effort, and deliberately not fatal to the announcement: a
        request the user can see but not answer from their phone is still
        a request they can answer in the settings UI.
        """
        if self._ensure_decisions_listener is None:
            return
        try:
            await self._ensure_decisions_listener()
        except Exception:
            logger.warning(
                "policy middleware: could not open the approval-response "
                "channel; the pending request is still queued and visible "
                "in the settings UI",
                exc_info=True,
            )

    def _resolve_already_decided(
        self,
        name: str,
        args_hash: str,
        *,
        dynamic_targets: bool,
        reads_remembered: bool,
        remember_minutes: int,
    ) -> bool:
        """Act on an entry this call did not create. True means dispatch now.

        A dynamic selector call must never consume an entry it did not
        itself create and is not itself still waiting on, so it skips this
        lookup entirely -- see the creator-only binding rationale above the
        call site in ``on_call_tool``.

        The claim cannot currently fail on this path: consuming an entry
        also removes it, and there is no ``await`` between the ``find()``
        and the claim, so no other task can interleave. It is checked
        anyway so that adding an await to this stretch degrades into an
        extra approval prompt rather than silently restoring the double
        dispatch the claim exists to stop.
        """
        if dynamic_targets:
            return False
        existing = self._queue.find(name, args_hash)
        if existing is None:
            return False
        if existing.decision == "approved":
            return self._claim_approval(
                existing,
                name,
                args_hash,
                reads_remembered=reads_remembered,
                remember_minutes=remember_minutes,
            )
        if existing.decision == "denied":
            self._queue.remove(existing.token)
            self._raise_denied_error()
        return False

    def _claim_approval(
        self,
        entry: PendingApproval,
        name: str,
        args_hash: str,
        *,
        reads_remembered: bool,
        remember_minutes: int,
    ) -> bool:
        """Consume an approved entry for this invocation.

        Exactly one caller may act on a given approval (see
        ``PendingApproval.claim``). A caller that loses the claim still
        proceeds when the winner's ``remember_minutes`` armed a
        remember-cache entry covering this exact call: that window is the
        user saying "stop asking for this", so re-prompting would
        contradict the rule they configured. The ``is_remembered`` gate
        earlier in ``on_call_tool`` ran before the approval existed, which
        is why it has to be re-checked here rather than relied upon.

        A call that skips that gate (``reads_remembered`` is false for a
        dynamic selector call and for every call under an allow list) must
        not consult the cache here either. Under an allow list an entry left
        over from a require-approval list can be live. For a dynamic
        selector call no reachable case arms one today
        (``has_dynamic_selector_targets`` is a pure function of the name and
        args that also produce ``args_hash``, so static and dynamic calls
        cannot collide on one key), but the guard keeps this branch
        degrading the same direction as the defensive claim check in
        ``_resolve_already_decided``: toward an extra prompt, never toward a
        dispatch the caller was not entitled to.
        """
        if self._queue.consume_and_maybe_remember(
            entry, remember_minutes=remember_minutes
        ):
            return True
        if not reads_remembered:
            return False
        return self._queue.is_remembered(name, args_hash)

    async def _new_pending(
        self,
        name: str,
        args_hash: str,
        args: dict[str, Any],
        *,
        policy: Policy,
        dynamic_targets: bool,
    ) -> PendingApproval:
        """Mint the pending entry this invocation will wait on.

        ``find_or_create`` serialises the create -- two concurrent calls
        with the same args_hash share one pending entry, so the user only
        sees one approval row. Sharing the row is safe; sharing the
        *decision* is not, which is what ``_claim_approval`` enforces.

        Dynamic selector calls must NOT share a pending entry at all: two
        concurrent identical calls can still resolve to different (or
        overlapping) target sets by the time each one dispatches, so
        folding them onto one approval would let a single click authorize
        a broader effect than the user saw. Skip the sharing and always
        mint a fresh entry.
        """
        if dynamic_targets:
            return self._queue.create(
                name, args_hash, args, ttl_minutes=policy.approval_ttl_minutes
            )
        return await self._queue.find_or_create(
            name, args_hash, args, ttl_minutes=policy.approval_ttl_minutes
        )

    def _finalize_timed_out_pending(
        self,
        pending: PendingApproval,
        *,
        dynamic_targets: bool,
        policy: Policy,
        name: str,
    ) -> PendingApproval:
        """Resolve a pending entry that timed out without a decision.

        Two mutually exclusive outcomes, split by ``dynamic_targets`` for
        the same reason the entry was never shared or looked up in the
        first place (see ``on_call_tool``'s creator-only binding
        comments):

        - Static: the entry may have been evicted by the queue's sweeper
          (TTL elapsed during the wait). A future re-call's own ``find()``
          lookup is how it gets consumed, so a dead token would strand
          that re-call forever -- reissue a fresh entry so the next
          re-call wakes a real pending row.
        - Dynamic: no re-call can ever look this entry up (creator-only
          binding), so reissuing would only mint a second, equally
          unreachable row. Instead the entry is removed here, before
          ``_raise_pending_error`` builds its message -- leaving it in
          the queue past this point would offer the settings UI a row
          that looks approvable but isn't (nothing is left holding this
          ``pending`` reference to act on the decision).
        """
        if dynamic_targets:
            self._queue.remove(pending.token)
            # INFO, matching the reissue log below: silently removing this
            # is otherwise the only state transition in this file that
            # leaves no trace, on a queue whose whole purpose is auditable
            # human approval. Without it, a user who clicks Approve a
            # moment after this call's wait window closed -- an ordinary
            # sequence, not an attack -- lands on
            # ApprovalQueue.approve's "unknown token" WARNING, which is
            # explicitly documented there as meaning a UI bug, a stale
            # tab, OR an attacker probing tokens. This line is what lets
            # an operator tell those apart.
            logger.info(
                "policy middleware: dynamic pending token %s removed after "
                "its single-use wait window closed for tool=%s; a late "
                "Approve click on it will log as an unknown token",
                pending.token,
                name,
            )
            return pending
        if self._queue.get(pending.token) is None:
            old_token = pending.token
            pending = self._queue.create(
                pending.tool_name,
                pending.args_hash,
                pending.args,
                ttl_minutes=policy.approval_ttl_minutes,
            )
            logger.info(
                "policy middleware: pending token %s evicted during wait, "
                "reissued as %s for tool=%s",
                old_token,
                pending.token,
                name,
            )
        return pending

    async def _wait_for_decision(
        self,
        context: MiddlewareContext,
        pending: PendingApproval,
        wait_seconds: float,
    ) -> None:
        deadline = anyio.current_time() + wait_seconds
        while anyio.current_time() < deadline and pending.decision == "pending":
            ctx = getattr(context, "fastmcp_context", None)
            await safe_progress(
                ctx,
                progress=0,
                total=0,
                message=(
                    "Awaiting user approval — open the ha-mcp settings UI, "
                    "go to the Tool Security Policies tab, and approve or deny "
                    "the pending request."
                ),
            )
            remaining = deadline - anyio.current_time()
            if remaining <= 0:
                break
            with anyio.move_on_after(min(15, remaining)):
                await pending.wait()

    @staticmethod
    def _raise_denied_error() -> NoReturn:
        raise_tool_error(
            create_error_response(
                ErrorCode.USER_DENIED,
                "User explicitly denied this tool call.",
                suggestions=[
                    "Do not retry without confirming with the user first.",
                ],
            )
        )

    def _raise_pending_error(
        self,
        pending: PendingApproval,
        rule: Rule | None = None,
        *,
        dynamic_targets: bool = False,
    ) -> NoReturn:
        """Raise the structured USER_APPROVAL_REQUIRED error for one pending entry.

        ``dynamic_targets`` switches both the message and suggestions: a
        dynamic selector entry is bound to the single invocation that
        created it (see the creator-only binding in ``on_call_tool``), was
        already removed from the queue by the caller just before this
        raises (nothing else could ever consume it), and can never be
        picked up by a later re-call -- so its wording must not promise the
        normal "re-call after the user approves" recovery path the
        non-dynamic case uses, and must not describe a still-open approval
        window: this is the ONLY call site, reached after
        ``_wait_for_decision`` returns with no decision, so the wait window
        has already closed by the time this message is built.
        """
        context: dict[str, Any] = {"token": pending.token}
        # Surface the matched rule so users (and the LLM) can tell at a
        # glance WHY the call was gated. Critical for "I added a
        # specific condition but every call is still gated" diagnostics.
        if rule is not None:
            context["matched_rule"] = {
                "tool_name": rule.tool_name,
                "when": [p.model_dump() for p in rule.when],
            }
        if dynamic_targets:
            # No expires_in_seconds here: the caller already removed this
            # entry from the queue before raising, so there is no live
            # countdown left to report -- a number here would read as
            # "there's still time", exactly the false impression this
            # message must not give.
            message = (
                "User approval required, and this specific request has "
                "already expired: it was single-use, bound to this one "
                "call only, and this call's wait window has now closed. "
                "The token above has already been removed and no longer "
                "exists -- there is nothing left to approve for this call. "
                "Re-call this tool to create a brand-new, independent "
                "request."
            )
            suggestions = [
                "Do not tell the user to approve the token above -- it no "
                + "longer exists and there is nothing left to approve.",
                "Re-call this tool with the same arguments to create a new "
                + "pending request, then have the user approve THAT one "
                + "while the new call is still waiting on it.",
            ]
        else:
            message = (
                "User approval required. Tell the user to open the ha-mcp "
                "settings UI, go to the Tool Security Policies tab, and "
                "approve or deny the pending request. Re-call this tool "
                "with the same arguments after the user approves."
            )
            suggestions = [
                "Tell the user to open the Tool Security Policies tab in "
                + "the ha-mcp settings UI and approve the pending request.",
                "Re-call this tool with the same arguments after the user approves.",
            ]
            # Time-remaining, not total TTL: an LLM that re-calls a minute
            # before expiry should see "~60s left", not the original 300s.
            # Meaningful only here: this entry survives past this call (a
            # later re-call's find() can still consume it), so its TTL is
            # a live, actionable number -- unlike the dynamic case above.
            remaining = max(
                0, int((pending.expires_at - datetime.now(UTC)).total_seconds())
            )
            context["expires_in_seconds"] = remaining
        raise_tool_error(
            create_error_response(
                ErrorCode.USER_APPROVAL_REQUIRED,
                message,
                suggestions=suggestions,
                context=context,
            )
        )
